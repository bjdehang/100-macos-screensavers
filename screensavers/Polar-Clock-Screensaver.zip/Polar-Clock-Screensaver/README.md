polar-clock-screensaver
=======================

![Preview](https://github.com/mikemcchillin/polar-clock-screensaver/raw/master/Web.saver/Contents/Resources/preview.png "Preview")

A screensaver of a simple d3 js Polar Clock inspired by [Pixel Breaker](http://blog.pixelbreaker.com/polarclock) that works on any MacOS, including Mavericks and Yosemite.

# Installation
Download the lastest version [here](https://github.com/MikeMcChillin/polar-clock-screensaver/releases/latest)

# Credits
[mbostock demo](http://bl.ocks.org/mbostock/1096355)
[momentjs](http://momentjs.com/)
[d3](d3js.org)