

---------------------------------------------------------------------------
How To Install


Double-click the .saver file.

Depending on your Security settings you might get a dialog box warning you
that the screen saver is from an “unidentified developer”.

To override this setting and install the screen saver anyway open
System Preferences > Security & Privacy and click Open Anyway.


---------------------------------------------------------------------------
How To Uninstall


Open System Preferences > Desktop & Screen Saver, right-click the screen
saver icon and choose Delete “SSJ???”.

Alternatively you can locate and delete the .saver file in the Finder.

If the screen saver was installed for ‘this user only’ the file path is:
HD/Users/~/Library/Screen Savers/SSJ???.saver

If it was installed for ‘all users of this computer’:
HD/Library/Screen Savers/SSJ???.saver


---------------------------------------------------------------------------
©2016 Johansson Design
